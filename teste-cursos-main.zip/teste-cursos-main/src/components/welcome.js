import '../components/welcome.scss';


const Welcome = () => {

  return (
    <div className='wel' id="Welcome">
      <a href="http://localhost:3000/">
      <h2>INSF</h2>
      </a>
    </div>
  );

}

export default Welcome