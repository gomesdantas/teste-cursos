
let respostas = ['CV', 'CV', 'Informação', 'Informação', 'CV', 'Administração', 'Informação', 'Informação'];

//
//
//
//

